import React, { useState } from 'react';
import { MenuItem, Category } from '../types';
import { Edit2, Trash2, Plus, Image as ImageIcon, Check, X } from 'lucide-react';

interface MenuManagerProps {
  menu: MenuItem[];
  onUpdateMenu: (newMenu: MenuItem[]) => void;
}

const CATEGORIES: Category[] = ['Pizza', 'Sides', 'Starters', 'Beverages', 'Desserts'];

const MenuManager: React.FC<MenuManagerProps> = ({ menu, onUpdateMenu }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<MenuItem>>({});
  const [isAdding, setIsAdding] = useState(false);

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      onUpdateMenu(menu.filter(item => item.id !== id));
    }
  };

  const handleEditClick = (item: MenuItem) => {
    setEditingId(item.id);
    setEditForm({ ...item });
    setIsAdding(false);
  };

  const handleAddClick = () => {
    setEditingId(null);
    setEditForm({
      name: '',
      description: '',
      price: 0,
      category: 'Pizza',
      image: 'https://picsum.photos/seed/new/400/300',
      isVegetarian: false,
      isVegan: false,
      isAvailable: true,
      isPopular: false,
    });
    setIsAdding(true);
  };

  const handleSave = () => {
    if (!editForm.name || !editForm.price) return;

    if (isAdding) {
      const newItem: MenuItem = {
        ...(editForm as MenuItem),
        id: Date.now().toString(),
        isGlutenFree: false // Default
      };
      onUpdateMenu([...menu, newItem]);
      setIsAdding(false);
    } else if (editingId) {
      onUpdateMenu(menu.map(item => item.id === editingId ? { ...item, ...editForm } as MenuItem : item));
      setEditingId(null);
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setIsAdding(false);
    setEditForm({});
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Menu Items</h2>
        <button 
          onClick={handleAddClick}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-medium transition-colors"
        >
          <Plus size={16} /> Add Item
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-xl border-2 border-green-100 shadow-sm mb-6">
          <h3 className="font-bold text-lg mb-4">Add New Item</h3>
          <MenuForm form={editForm} setForm={setEditForm} onSave={handleSave} onCancel={handleCancel} />
        </div>
      )}

      <div className="grid gap-4">
        {menu.map(item => (
          <div key={item.id} className={`bg-white p-4 rounded-xl shadow-sm border ${editingId === item.id ? 'border-blue-500 ring-2 ring-blue-100' : 'border-gray-100'}`}>
            {editingId === item.id ? (
              <MenuForm form={editForm} setForm={setEditForm} onSave={handleSave} onCancel={handleCancel} />
            ) : (
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg bg-gray-100" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-900">{item.name}</h3>
                    <span className="text-xs px-2 py-0.5 bg-gray-100 rounded-full text-gray-600">{item.category}</span>
                    {item.isPopular && <span className="text-xs px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full">Popular</span>}
                    {!item.isAvailable && <span className="text-xs px-2 py-0.5 bg-red-100 text-red-700 rounded-full">Sold Out</span>}
                  </div>
                  <p className="text-sm text-gray-500 line-clamp-1">{item.description}</p>
                  <p className="font-semibold text-gray-900 mt-1">₹{item.price}</p>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button 
                    onClick={() => handleEditClick(item)}
                    className="p-2 text-gray-500 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="p-2 text-gray-500 hover:bg-red-50 hover:text-red-600 rounded-lg transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const MenuForm: React.FC<{
  form: Partial<MenuItem>;
  setForm: (f: Partial<MenuItem>) => void;
  onSave: () => void;
  onCancel: () => void;
}> = ({ form, setForm, onSave, onCancel }) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Name</label>
          <input 
            type="text" 
            value={form.name || ''} 
            onChange={e => setForm({...form, name: e.target.value})}
            className="w-full p-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Category</label>
          <select 
            value={form.category} 
            onChange={e => setForm({...form, category: e.target.value as Category})}
            className="w-full p-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
          >
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs font-medium text-gray-500 mb-1">Description</label>
          <textarea 
            value={form.description || ''} 
            onChange={e => setForm({...form, description: e.target.value})}
            className="w-full p-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            rows={2}
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Price (₹)</label>
          <input 
            type="number" 
            value={form.price || 0} 
            onChange={e => setForm({...form, price: parseFloat(e.target.value)})}
            className="w-full p-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            step="1"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Image URL</label>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={form.image || ''} 
              onChange={e => setForm({...form, image: e.target.value})}
              className="w-full p-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <button className="p-2 bg-gray-100 rounded-lg text-gray-500 hover:bg-gray-200">
                <ImageIcon size={18} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-4 py-2">
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isAvailable} onChange={e => setForm({...form, isAvailable: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500" />
          <span className="text-sm">Available</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isPopular} onChange={e => setForm({...form, isPopular: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500" />
          <span className="text-sm">Popular</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isVegetarian} onChange={e => setForm({...form, isVegetarian: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500" />
          <span className="text-sm">Vegetarian</span>
        </label>
         <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isVegan} onChange={e => setForm({...form, isVegan: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500" />
          <span className="text-sm">Vegan</span>
        </label>
      </div>

      <div className="flex justify-end gap-3 pt-2">
        <button onClick={onCancel} className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
        <button onClick={onSave} className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium flex items-center gap-2">
          <Check size={16} /> Save Changes
        </button>
      </div>
    </div>
  );
}

export default MenuManager;