import { GoogleGenAI } from "@google/genai";
import { MenuItem } from "../types";

// Helper to get the AI instance safely
const getAIInstance = () => {
    const apiKey = process.env.API_KEY || '';
    if (!apiKey) {
        console.warn("API Key is missing. AI features will respond with mock data.");
        return null;
    }
    return new GoogleGenAI({ apiKey });
};

export const generateChatResponse = async (
    userMessage: string, 
    menuContext: MenuItem[], 
    history: {role: string, parts: {text: string}[]}[]
): Promise<string> => {
    const ai = getAIInstance();
    
    // Fallback if no API key
    if (!ai) {
        return "I'm currently operating in offline mode. Please contact the restaurant directly for specific inquiries, or check our menu section!";
    }

    try {
        const menuDescription = menuContext.map(item => 
            `${item.name} (${item.category}): ₹${item.price} - ${item.description} ${item.isVegetarian ? '[Veg]' : ''} ${item.isVegan ? '[Vegan]' : ''}`
        ).join('\n');

        const systemInstruction = `You are "Luigi", a charming and helpful AI concierge for PizzaHut Remastered.
        
        Your goal is to assist customers with:
        1. Choosing items from the menu based on their preferences (spicy, vegan, cheap, etc.).
        2. Explaining ingredients.
        3. Encouraging them to book a table.
        
        Here is the current menu (Prices in INR):
        ${menuDescription}
        
        Keep your responses concise (under 100 words), warm, and appetizing. 
        If asked about booking, guide them to click the "Book a Table" button.
        Do not make up menu items that are not in the list.`;

        const model = 'gemini-3-flash-preview';
        
        const contents = [
            ...history.map(h => ({
                role: h.role,
                parts: h.parts
            })),
            {
                role: 'user',
                parts: [{ text: userMessage }]
            }
        ];

        const response = await ai.models.generateContent({
            model,
            contents,
            config: {
                systemInstruction,
                temperature: 0.7,
            }
        });

        return response.text || "I'm sorry, I couldn't quite catch that. Could you repeat?";

    } catch (error) {
        console.error("Gemini API Error:", error);
        return "I'm having a little trouble connecting to the kitchen right now. Please try again in a moment.";
    }
};